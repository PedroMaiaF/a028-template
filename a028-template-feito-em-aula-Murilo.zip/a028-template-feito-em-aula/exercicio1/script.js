
//Prática Guiada 1
//Criar uma nova tag li
const itemNovo = document.createElement("li")
console.log(itemNovo)

//criando conteúdo
const conteudoItemNovo = document.createTextNode("item 0")
console.log(conteudoItemNovo)

//Adicionando conteúdo na elemento
itemNovo.appendChild(conteudoItemNovo)
console.log(itemNovo)

//definir conteudo de referencia
const elementoReferencia = document.getElementById("lista")
console.log(elementoReferencia)

//adicionar na tela
elementoReferencia.insertAdjacentElement("afterbegin",itemNovo)

//ELEMENTO 5
const itemFinal = document.createElement("li")

const conteudoItemFinal = document.createTextNode("item 5")

itemFinal.appendChild(conteudoItemFinal)
console.log(itemFinal)

elementoReferencia.insertAdjacentElement("beforeend", itemFinal)



